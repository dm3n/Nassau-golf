import {defineCliConfig} from 'sanity/cli'

export default defineCliConfig({
  api: {
    projectId: 'j1ypjfte',
    dataset: 'production'
  }
})
