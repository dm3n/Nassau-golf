import React from "react";

function FiveStar() {
  return (
    <>
      <svg viewBox="0 0 1024 1024" className="item-card-icon">
        <path
          d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"
          className=""
        ></path>
      </svg>
      <svg viewBox="0 0 1024 1024" className="item-card-icon02">
        <path
          d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"
          className=""
        ></path>
      </svg>
      <svg viewBox="0 0 1024 1024" className="item-card-icon04">
        <path
          d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"
          className=""
        ></path>
      </svg>
      <svg viewBox="0 0 1024 1024" className="item-card-icon06">
        <path
          d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"
          className=""
        ></path>
      </svg>
      <svg viewBox="0 0 1024 1024" className="item-card-icon08">
        <path
          d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"
          className=""
        ></path>
      </svg>
    </>
  );
}

export default FiveStar;
